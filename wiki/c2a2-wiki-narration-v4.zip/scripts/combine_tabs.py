#!/usr/bin/env python3
"""
Combine two self-contained HTML visualization pages (Sociogram + 3D PRS)
into a single tabbed page.

Usage:
    python3 combine_tabs.py <sociogram.html> <prs_3d.html> <output.html>
"""

import sys
import re
import os


def read_file(path):
    with open(path, 'r', encoding='utf-8') as f:
        return f.read()


def extract_cdn_scripts(html):
    """Extract <script src="..."></script> tags and return list of src URLs."""
    pattern = r'<script\s+src="([^"]+)"[^>]*>\s*</script>'
    return re.findall(pattern, html)


def extract_style(html):
    """Extract content between <style> and </style> tags."""
    pattern = r'<style>(.*?)</style>'
    match = re.search(pattern, html, re.DOTALL)
    return match.group(1) if match else ''


def extract_body(html):
    """Extract content between <body> and </body> tags."""
    pattern = r'<body[^>]*>(.*?)</body>'
    match = re.search(pattern, html, re.DOTALL)
    return match.group(1).strip() if match else ''


def extract_inline_scripts(html):
    """Extract inline script content (scripts without src attribute)."""
    # Match <script> tags that don't have src attribute
    pattern = r'<script>([^<].*?)</script>'
    matches = re.findall(pattern, html, re.DOTALL)
    return '\n'.join(matches)


def remove_script_tags(body_html):
    """Remove all script tags (both CDN and inline) from body HTML."""
    # Remove CDN script tags
    body_html = re.sub(r'<script\s+src="[^"]*"[^>]*>\s*</script>\s*', '', body_html)
    # Remove inline script tags
    body_html = re.sub(r'<script>[^<].*?</script>\s*', '', body_html, flags=re.DOTALL)
    return body_html


def rename_prs_ids(css, body, js):
    """Rename conflicting IDs in the 3D PRS content."""
    # CSS: #header -> #prs-header, #tooltip -> #prs-tooltip
    css = re.sub(r'#header\b', '#prs-header', css)
    css = re.sub(r'#tooltip\b', '#prs-tooltip', css)

    # Body HTML: id="header" -> id="prs-header", id="tooltip" -> id="prs-tooltip"
    body = body.replace('id="header"', 'id="prs-header"')
    body = body.replace('id="tooltip"', 'id="prs-tooltip"')

    # JS: getElementById('header') -> getElementById('prs-header')
    js = js.replace("getElementById('header')", "getElementById('prs-header')")
    js = js.replace('getElementById("header")', 'getElementById("prs-header")')
    js = js.replace("getElementById('tooltip')", "getElementById('prs-tooltip')")
    js = js.replace('getElementById("tooltip")', 'getElementById("prs-tooltip")')

    return css, body, js


def strip_global_css_rules(css):
    """Remove *, body, html rules from CSS to avoid duplication."""
    # Remove * { ... } rules
    css = re.sub(r'^\s*\*\s*\{[^}]*\}\s*$', '', css, flags=re.MULTILINE)
    # Remove body { ... } rules
    css = re.sub(r'^\s*body\s*\{[^}]*\}\s*$', '', css, flags=re.MULTILINE)
    # Remove html, body { ... } rules
    css = re.sub(r'^\s*html\s*,\s*body\s*\{[^}]*\}\s*$', '', css, flags=re.MULTILINE)
    return css


def make_prs_js_lazy(js):
    """Modify the PRS JS to expose init via window.initPRS3D instead of calling directly."""
    # Remove the INIT block: comment + init() + buildZAxis() + buildTraditionFilters()
    js = re.sub(
        r'\n// ── INIT ──\s*\n'
        r'init\(\);\s*\n'
        r'buildZAxis\(\);\s*\n'
        r'(?:buildTraditionFilters\(\);\s*\n?)?',
        '\n', js
    )
    # Remove the search event listener that runs at load time
    # (it will be re-attached inside initPRS3D via buildTraditionFilters)
    js = re.sub(
        r"\n// ── SEARCH EVENT ──\s*\n"
        r"document\.getElementById\('prs-search-box'\)\.addEventListener\([^)]+,\s*function\(e\)\s*\{\s*\n"
        r"\s*prsSearch\(e\.target\.value\);\s*\n"
        r"\}\);\s*\n",
        '\n', js
    )
    # Fallback: also strip bare init/buildZAxis/buildTraditionFilters at end
    js = re.sub(r'\binit\(\);\s*\nbuildZAxis\(\);\s*\n(?:buildTraditionFilters\(\);\s*)?\s*$', '', js)
    return js


def build_combined(sociogram_path, prs3d_path, output_path):
    sociogram_html = read_file(sociogram_path)
    prs3d_html = read_file(prs3d_path)

    # Extract components from sociogram
    socio_cdns = extract_cdn_scripts(sociogram_html)
    socio_css = extract_style(sociogram_html)
    socio_body = extract_body(sociogram_html)
    socio_js = extract_inline_scripts(sociogram_html)
    socio_body = remove_script_tags(socio_body)

    # Extract components from PRS 3D
    prs_cdns = extract_cdn_scripts(prs3d_html)
    prs_css_raw = extract_style(prs3d_html)
    prs_body = extract_body(prs3d_html)
    prs_js_raw = extract_inline_scripts(prs3d_html)
    prs_body = remove_script_tags(prs_body)

    # Rename conflicting IDs in PRS
    prs_css, prs_body, prs_js = rename_prs_ids(prs_css_raw, prs_body, prs_js_raw)

    # Strip global CSS rules from PRS (sociogram's are the base)
    prs_css = strip_global_css_rules(prs_css)

    # Make PRS JS lazy-initializable
    prs_js = make_prs_js_lazy(prs_js)

    # Deduplicate CDN scripts
    all_cdns = []
    seen = set()
    for url in socio_cdns + prs_cdns:
        if url not in seen:
            all_cdns.append(url)
            seen.add(url)

    cdn_tags = '\n'.join('<script src="' + url + '"></script>' for url in all_cdns)

    # Build shared header CSS
    shared_css = """
/* ── SHARED TAB HEADER ── */
#shared-header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 6px 16px;
  background: #111118;
  border-bottom: 2px solid #2a2a3a;
  height: 42px;
  flex-shrink: 0;
  z-index: 1000;
  position: relative;
}
#shared-header .sh-title {
  font-size: 16px;
  font-weight: 700;
  color: #FFD700;
  white-space: nowrap;
}
#shared-header .tab-buttons {
  display: flex;
  gap: 6px;
}
.tab-btn {
  background: #1a1a2a;
  border: 1px solid #3a3a4a;
  color: #b0b0b0;
  padding: 5px 16px;
  border-radius: 20px;
  cursor: pointer;
  font-size: 13px;
  font-weight: 600;
  transition: all 0.15s ease;
}
.tab-btn:hover {
  background: #2a2a3a;
  color: #e0e0e0;
}
.tab-btn.active {
  background: #FFD700;
  color: #0a0a0f;
  border-color: #FFD700;
}
.tab-content {
  flex: 1;
  overflow: hidden;
  position: relative;
}
#tab-sociogram {
  display: flex;
  flex-direction: column;
  height: calc(100vh - 42px);
}
#tab-prs3d {
  height: calc(100vh - 42px);
  position: relative;
}
"""

    # Build the shared header HTML
    shared_header_html = """<div id="shared-header">
  <span class="sh-title">C2A2 Wiki Explorer</span>
  <div class="tab-buttons">
    <button class="tab-btn active" data-tab="sociogram" onclick="switchTab('sociogram')">Sociogram</button>
    <button class="tab-btn" data-tab="prs3d" onclick="switchTab('prs3d')">3D PRS</button>
  </div>
</div>"""

    # Build tab-switching JS
    tab_js = """
var prs3dInitialized = false;
function switchTab(tabName) {
  var socioTab = document.getElementById('tab-sociogram');
  var prsTab = document.getElementById('tab-prs3d');
  socioTab.style.display = tabName === 'sociogram' ? '' : 'none';
  prsTab.style.display = tabName === 'prs3d' ? '' : 'none';
  document.querySelectorAll('.tab-btn').forEach(function(b) {
    b.classList.toggle('active', b.dataset.tab === tabName);
  });
  if (tabName === 'prs3d' && !prs3dInitialized) {
    prs3dInitialized = true;
    // Delay init to allow browser reflow after display change
    setTimeout(function() {
      try {
        if (typeof initPRS3D === 'function') initPRS3D();
      } catch(e) {
        console.error('initPRS3D error:', e);
      }
    }, 50);
  }
  window.dispatchEvent(new Event('resize'));
}
"""

    # Adjust sociogram CSS: the #app inside #tab-sociogram needs full height
    # The sociogram body had html,body 100% height, but now the tab container manages that
    # We need #tab-sociogram #app to fill its container
    socio_css_adjusted = socio_css + """
#tab-sociogram #app { height: 100%; }
"""

    # Scope PRS CSS under #tab-prs3d for conflicting selectors
    # Most PRS selectors are unique (#canvas-container, #info-panel, #legend, etc.)
    # The ones we already renamed (#prs-header, #prs-tooltip).
    # Add #tab-prs3d scoping for canvas-container positioning
    prs_css_scoped = prs_css + """
/* Override standalone 100vh to fit inside tab container */
#tab-prs3d #prs-layout {
  height: 100%;
  width: 100%;
}
#tab-prs3d #canvas-container {
  position: absolute;
  top: 0; left: 0;
  width: 100%; height: 100%;
}
"""

    # Sociogram JS: NOT wrapped in IIFE — its functions must remain globally
    # accessible for inline onclick handlers in the HTML. It already scopes
    # via DOMContentLoaded internally. The two conflicting globals
    # (CROSS_CONNECTIONS, FINDINGS) are acceptable since each tab reads
    # its own copy at load time.
    socio_js_wrapped = socio_js

    # PRS JS: wrapped in IIFE to isolate its globals, but expose functions
    # needed by inline handlers to the window object
    prs_js_wrapped = ("(function() {\n" + prs_js
                      + "\nwindow.initPRS3D = function() { init(); buildZAxis(); buildTraditionFilters(); document.getElementById('prs-search-box').addEventListener('input', function(e) { prsSearch(e.target.value); }); };"
                      + "\nwindow.prsToggleThinker = prsToggleThinker;"
                      + "\nwindow.prsToggleAll = prsToggleAll;"
                      + "\nwindow.prsClearSearch = prsClearSearch;"
                      + "\nwindow.prsSearch = prsSearch;"
                      + "\nwindow.resetCamera = resetCamera;"
                      + "\nwindow.toggleLabels = toggleLabels;"
                      + "\nwindow.toggleThreads = toggleThreads;"
                      + "\nwindow.toggleDiscs = toggleDiscs;"
                      + "\nwindow.closePanel = closePanel;"
                      + "\nwindow.prsSearchClickResult = prsSearchClickResult;"
                      + "\n})();")

    # Assemble the final HTML using string concatenation (NOT f-strings)
    output = ('<!DOCTYPE html>\n'
              '<html lang="en">\n'
              '<head>\n'
              '<meta charset="UTF-8">\n'
              '<meta name="viewport" content="width=device-width, initial-scale=1.0">\n'
              '<title>C2A2 Wiki Explorer</title>\n'
              + cdn_tags + '\n'
              '<style>\n'
              + socio_css_adjusted
              + '\n/* ── PRS 3D STYLES ── */\n'
              + prs_css_scoped
              + '\n/* ── SHARED STYLES ── */\n'
              + shared_css
              + '\n</style>\n'
              '</head>\n'
              '<body>\n'
              + shared_header_html + '\n'
              '<div id="tab-sociogram" class="tab-content active">\n'
              + socio_body + '\n'
              '</div>\n'
              '<div id="tab-prs3d" class="tab-content" style="display:none">\n'
              + prs_body + '\n'
              '</div>\n'
              '<script>\n'
              '// ── TAB SWITCHING ──\n'
              + tab_js + '\n'
              '// ── SOCIOGRAM JS ──\n'
              + socio_js_wrapped + '\n'
              '// ── PRS 3D JS ──\n'
              + prs_js_wrapped + '\n'
              '</script>\n'
              '</body>\n'
              '</html>\n')

    with open(output_path, 'w', encoding='utf-8') as f:
        f.write(output)

    size_kb = os.path.getsize(output_path) / 1024
    print("Combined HTML written to: " + output_path)
    print("Size: %.1f KB" % size_kb)
    return output_path


def main():
    if len(sys.argv) != 4:
        print("Usage: combine_tabs.py <sociogram.html> <prs_3d.html> <output.html>")
        sys.exit(1)

    sociogram_path = sys.argv[1]
    prs3d_path = sys.argv[2]
    output_path = sys.argv[3]

    if not os.path.exists(sociogram_path):
        print("Error: sociogram file not found: " + sociogram_path)
        sys.exit(1)
    if not os.path.exists(prs3d_path):
        print("Error: PRS 3D file not found: " + prs3d_path)
        sys.exit(1)

    build_combined(sociogram_path, prs3d_path, output_path)


if __name__ == '__main__':
    main()
