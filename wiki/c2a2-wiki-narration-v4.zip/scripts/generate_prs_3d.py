#!/usr/bin/env python3
"""
Generate a self-contained 3D PRS visualization HTML from vault data.
Uses Three.js r128 for 3D rendering.

Usage:
    python3 generate_prs_3d.py <vault_data.json> <output.html>
"""

import json
import re
import sys
import os

# ── THINKER → DISCIPLINE MAPPING ──
# Academic disciplines as pie slices; thinkers placed within their discipline
DISCIPLINE_MAP = {
    "levin": "Developmental Biology",
    "friston": "Computational Neuroscience",
    "hoffman": "Cognitive Science",
    "kastrup": "Philosophy of Mind",
    "mcgilchrist": "Neuropsychiatry",
    "hawkins": "Computational Neuroscience",
    "wolfram": "Mathematical Physics",
    "carroll": "Theoretical Physics",
    "arkanihamed": "Theoretical Physics",
    "fredrickson": "Positive Psychology",
    "stump": "Analytic Theology",
    "rohr": "Contemplative Theology",
    "wright": "Historical Theology",
    "macintyre": "Moral Philosophy",
    "loughran": "Systems Integration",
    "master": "Systems Integration",
}

# Same color palette as the sociogram
THINKER_COLORS = {
    "levin": "#C45B5B",
    "friston": "#5A8EAF",
    "hoffman": "#C08B3E",
    "kastrup": "#8B5DAB",
    "mcgilchrist": "#3D9E89",
    "hawkins": "#B87D3E",
    "wolfram": "#4A5E6D",
    "carroll": "#4E8A5E",
    "arkanihamed": "#A85D3A",
    "fredrickson": "#C47A9A",
    "stump": "#A8923A",
    "rohr": "#9A7A5A",
    "wright": "#5A72A8",
    "macintyre": "#7A6A8A",
    "loughran": "#4A8A7A",
    "master": "#C9A84C",
}

THINKER_DISPLAY = {
    "levin": "Levin",
    "friston": "Friston",
    "hoffman": "Hoffman",
    "kastrup": "Kastrup",
    "mcgilchrist": "McGilchrist",
    "hawkins": "Hawkins",
    "wolfram": "Wolfram",
    "carroll": "Carroll",
    "arkanihamed": "Arkani-Hamed",
    "fredrickson": "Fredrickson",
    "stump": "Stump",
    "rohr": "Rohr",
    "wright": "Wright",
    "macintyre": "MacIntyre",
    "loughran": "Loughran",
    "master": "C2A2 Master",
}

# ── REAL PUBLICATION DATES (override wiki-added dates) ──
# Researched seminal publication year for each thinker's PRS triplets
PUBLICATION_YEARS = {
    "arkanihamed": {"1": 1998, "2": 2013},   # ADD extra dimensions; Amplituhedron
    "carroll":     {"1": 2004, "2": 2016},   # Spacetime & Geometry / MWI; The Big Picture
    "fredrickson": {"1": 1998, "2": 2013},   # Broaden-and-build; Love 2.0
    "friston":     {"1": 2003, "2": 2010},   # Dynamic Causal Modeling; FEP Nature Reviews
    "hawkins":     {"1": 2004, "2": 2021},   # On Intelligence; A Thousand Brains
    "hoffman":     {"1": 2008, "2": 2019},   # Conscious Realism paper; Case Against Reality
    "kastrup":     {"1": 2014, "2": 2019},   # Why Materialism Is Baloney; Idea of the World
    "levin":       {"1": 2007, "2": 2021, "3": 2022},  # Bioelectric morphogenesis; Cell 2021; attractor formalism
    "loughran":    {"1": 2021, "2": 2026, "3": 2026, "4": 2026, "5": 2022, "6": 2022, "7": 2022},  # DCEC 2021; C2A2 2026; ISME 2022
    "macintyre":   {"1": 1977, "2": 1981},   # Epistemological Crises (Monist); After Virtue
    "master":      {"1": 2021, "2": 2026},   # PRS methodology origin; C2A2 deployment
    "mcgilchrist": {"1": 2009, "2": 2021},   # Master & His Emissary; Matter with Things
    "rohr":        {"1": 2009, "2": 2011},   # The Naked Now; Falling Upward
    "stump":       {"1": 2003, "2": 2010},   # Aquinas (Routledge); Wandering in Darkness
    "wolfram":     {"1": 2002, "2": 2020},   # A New Kind of Science; Wolfram Physics Project
    "wright":      {"1": 1992, "2": 2005},   # NT & People of God; The Last Word
}


def get_publication_date(thinker, prs_num):
    """Get the real publication date string for a thinker's PRS triplet."""
    years = PUBLICATION_YEARS.get(thinker, {})
    # prs_num may be "01", "02" etc — strip leading zeros
    normalized = str(int(prs_num))
    year = years.get(normalized, None)
    if year:
        return f"{year}-06-01"  # mid-year approximation
    return None


def parse_prs_triplets(data):
    """Extract PRS triplets from vault data files."""
    triplets = []
    seen = set()

    prs_files = [f for f in data["files"]
                 if "prs_triplets" in f["filepath"].lower() and f["content"]]

    # Deduplicate: prefer the longest version of each thinker's file
    by_thinker = {}
    for pf in prs_files:
        parts = pf["filepath"].split("/")
        thinker = "master"
        for i, p in enumerate(parts):
            if p == "traditions" and i + 1 < len(parts):
                thinker = parts[i + 1]
        if thinker not in by_thinker or len(pf["content"]) > len(by_thinker[thinker]["content"]):
            by_thinker[thinker] = pf
            by_thinker[thinker]["_thinker"] = thinker

    for thinker, pf in sorted(by_thinker.items()):
        content = pf["content"]
        # Parse PRS blocks
        blocks = re.split(r'\n(?=PRS-\d+:)', content)
        for block in blocks:
            m = re.match(r'PRS-(\d+):', block)
            if not m:
                continue

            prs_num = m.group(1)
            key = f"{thinker}-PRS-{prs_num}"
            if key in seen:
                continue
            seen.add(key)

            # Extract fields
            problem = ""
            resource = ""
            solution = ""
            date = ""
            confidence = "Medium"
            label = ""

            for line in block.split("\n"):
                line = line.strip()
                if line.startswith("Problem:"):
                    problem = line[8:].strip()
                elif line.startswith("Resource:"):
                    resource = line[9:].strip()
                elif line.startswith("Solution:"):
                    solution = line[9:].strip()
                elif line.startswith("Date Added:"):
                    date = line[11:].strip()
                elif line.startswith("Confidence:"):
                    confidence = line[11:].strip()
                elif line.startswith("Label:"):
                    label = line[6:].strip()

            if problem or resource or solution:
                # Override with real publication date
                pub_date = get_publication_date(thinker, prs_num)
                real_date = pub_date if pub_date else date

                triplets.append({
                    "id": key,
                    "thinker": thinker,
                    "prs_num": prs_num,
                    "label": label,
                    "problem": problem,
                    "resource": resource,
                    "solution": solution,
                    "date": real_date,
                    "pub_year": int(real_date[:4]) if real_date else 2020,
                    "confidence": confidence,
                })

    return triplets


def parse_cross_connections(data):
    """Extract cross-tradition connections."""
    crosses = []
    for cc in data.get("cross_connections", []):
        crosses.append({
            "id": cc["id"],
            "question": cc.get("question", ""),
            "programs": cc.get("programs", ""),
            "nature": cc.get("nature", ""),
            "notes": cc.get("notes", ""),
        })
    return crosses


def parse_findings(data):
    """Extract findings."""
    findings = []
    for f in data.get("findings", []):
        findings.append({
            "id": f["id"],
            "date": f.get("date", ""),
            "programs": f.get("programs", ""),
            "type": f.get("type", ""),
            "finding": f.get("finding", ""),
        })
    return findings


def build_html(triplets, crosses, findings, data):
    """Build the complete self-contained HTML."""

    # Collect unique disciplines and assign angular positions
    disciplines = sorted(set(DISCIPLINE_MAP.values()))

    disc_data = json.dumps(disciplines)
    thinker_disc_data = json.dumps(DISCIPLINE_MAP)
    thinker_color_data = json.dumps(THINKER_COLORS)
    thinker_display_data = json.dumps(THINKER_DISPLAY)
    triplet_data = json.dumps(triplets)
    cross_data = json.dumps(crosses)
    finding_data = json.dumps(findings)

    html = """<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>C2A2 — 3D PRS Landscape</title>
<style>
* { margin: 0; padding: 0; box-sizing: border-box; }
body {
  background: #0a0a0f;
  color: #d0d0d0;
  font-family: 'Inter', -apple-system, BlinkMacSystemFont, sans-serif;
  overflow: hidden;
  height: 100vh;
  width: 100vw;
}

#prs-layout {
  display: flex;
  height: 100vh;
  width: 100vw;
}

#prs-left-panel {
  width: 200px;
  flex-shrink: 0;
  background: #0e0e16;
  overflow-y: auto;
  padding: 8px;
  font-size: 12px;
  z-index: 100;
  border-right: 1px solid #1a1a2e;
}
#prs-left-panel h3 {
  color: #888;
  font-size: 11px;
  text-transform: uppercase;
  margin: 8px 0 4px 0;
  letter-spacing: 1px;
}
.prs-filter-item {
  display: flex;
  align-items: center;
  gap: 6px;
  padding: 2px 0;
  cursor: pointer;
}
.prs-filter-item input[type="checkbox"] { cursor: pointer; }
.prs-filter-dot {
  width: 10px;
  height: 10px;
  border-radius: 50%;
  display: inline-block;
  flex-shrink: 0;
}
.prs-filter-label {
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}
#prs-search-box {
  width: 100%;
  background: #1a1a2a;
  border: 1px solid #3a3a4a;
  color: #e0e0e0;
  padding: 6px 8px;
  border-radius: 4px;
  font-size: 12px;
  margin-top: 4px;
}
#prs-search-box::placeholder { color: #666; }
#prs-search-box:focus { outline: none; border-color: #FFD700; }
.prs-search-results {
  margin-top: 6px;
  font-size: 11px;
  color: #888;
}
.prs-search-hit {
  padding: 4px 6px;
  margin: 2px 0;
  background: #1a1a2a;
  border-radius: 3px;
  cursor: pointer;
  color: #ccc;
  line-height: 1.3;
}
.prs-search-hit:hover { background: #2a2a3a; }
.prs-search-hit .hit-thinker { font-weight: 600; }
#prs-search-clear {
  background: #1a1a2a;
  border: 1px solid #3a3a4a;
  color: #e0e0e0;
  padding: 2px 8px;
  border-radius: 4px;
  cursor: pointer;
  font-size: 11px;
  display: none;
  margin-top: 4px;
}
#prs-search-clear:hover { background: #2a2a3a; }

#canvas-container {
  flex: 1;
  position: relative;
  overflow: hidden;
}

#header {
  position: absolute;
  top: 0; left: 0; right: 0;
  height: 44px;
  background: rgba(10, 10, 15, 0.85);
  backdrop-filter: blur(8px);
  border-bottom: 1px solid #1a1a2e;
  display: flex;
  align-items: center;
  padding: 0 16px;
  z-index: 100;
  gap: 12px;
}
#header h1 {
  font-size: 14px;
  font-weight: 600;
  color: #C9A84C;
  white-space: nowrap;
}
#header .controls {
  display: flex;
  gap: 6px;
  align-items: center;
  margin-left: auto;
}
#header .controls button {
  background: #1a1a2e;
  border: 1px solid #2a2a3e;
  color: #d0d0d0;
  padding: 4px 10px;
  border-radius: 4px;
  font-size: 12px;
  cursor: pointer;
}
#header .controls button:hover { background: #2a2a3e; }
#header .controls button.active { background: #FFD700; color: #0a0a0f; border-color: #FFD700; }

#info-panel {
  position: absolute;
  top: 54px;
  right: 10px;
  width: 340px;
  max-height: calc(100vh - 70px);
  background: rgba(12, 12, 20, 0.92);
  backdrop-filter: blur(10px);
  border: 1px solid #1a1a2e;
  border-radius: 8px;
  padding: 16px;
  overflow-y: auto;
  z-index: 90;
  display: none;
  font-size: 13px;
  line-height: 1.5;
}
#info-panel h3 {
  color: #C9A84C;
  font-size: 15px;
  margin-bottom: 8px;
}
#info-panel .prs-type {
  display: inline-block;
  padding: 2px 8px;
  border-radius: 3px;
  font-size: 11px;
  font-weight: 600;
  margin-bottom: 8px;
}
#info-panel .prs-type.problem { background: #C45B5B33; color: #E87070; }
#info-panel .prs-type.resource { background: #5A8EAF33; color: #7AB0CF; }
#info-panel .prs-type.solution { background: #3D9E8933; color: #5DC0AB; }
#info-panel .field-label {
  color: #888;
  font-size: 11px;
  text-transform: uppercase;
  letter-spacing: 0.5px;
  margin-top: 10px;
}
#info-panel .field-value {
  color: #d0d0d0;
  margin-top: 2px;
}
#info-panel .close-btn {
  position: absolute;
  top: 8px;
  right: 12px;
  background: none;
  border: none;
  color: #666;
  font-size: 18px;
  cursor: pointer;
}
#info-panel .close-btn:hover { color: #aaa; }
#info-panel .thinker-tag {
  display: inline-block;
  padding: 2px 8px;
  border-radius: 3px;
  font-size: 11px;
  font-weight: 600;
  margin-right: 4px;
}

#legend {
  position: absolute;
  bottom: 10px;
  left: 10px;
  background: rgba(12, 12, 20, 0.88);
  backdrop-filter: blur(8px);
  border: 1px solid #1a1a2e;
  border-radius: 8px;
  padding: 12px 14px;
  z-index: 90;
  font-size: 11px;
  max-height: 300px;
  overflow-y: auto;
}
#legend h4 {
  color: #C9A84C;
  margin-bottom: 6px;
  font-size: 12px;
}
#legend .legend-item {
  display: flex;
  align-items: center;
  gap: 6px;
  margin: 3px 0;
  cursor: pointer;
  opacity: 1;
  transition: opacity 0.2s;
}
#legend .legend-item.dimmed { opacity: 0.3; }
#legend .legend-dot {
  width: 10px;
  height: 10px;
  border-radius: 50%;
  flex-shrink: 0;
}

#tooltip {
  position: absolute;
  background: rgba(12, 12, 20, 0.95);
  border: 1px solid #2a2a3e;
  border-radius: 6px;
  padding: 8px 12px;
  font-size: 12px;
  color: #d0d0d0;
  pointer-events: none;
  z-index: 200;
  display: none;
  max-width: 300px;
}

#disc-labels { position: absolute; top: 0; left: 0; width: 100%; height: 100%; pointer-events: none; z-index: 50; }
.disc-label {
  position: absolute;
  color: #888;
  font-size: 11px;
  font-weight: 500;
  text-transform: uppercase;
  letter-spacing: 1px;
  pointer-events: none;
  white-space: nowrap;
}

/* Scrollbar */
::-webkit-scrollbar { width: 6px; }
::-webkit-scrollbar-track { background: transparent; }
::-webkit-scrollbar-thumb { background: #2a2a3e; border-radius: 3px; }
</style>
</head>
<body>

<div id="prs-layout">

<div id="prs-left-panel">
  <h3>Traditions</h3>
  <div class="prs-filter-item">
    <input type="checkbox" id="prs-chk-all" checked onchange="prsToggleAll(this.checked)">
    <span class="prs-filter-label" style="font-weight:600">All</span>
  </div>
  <div id="prs-tradition-filters"></div>
  <hr style="border:none;border-top:1px solid #2a2a3a;margin:8px 0">
  <h3>Search PRS</h3>
  <input type="text" id="prs-search-box" placeholder="Search problems, resources, solutions...">
  <button id="prs-search-clear" onclick="prsClearSearch()">Clear</button>
  <div id="prs-search-results" class="prs-search-results"></div>
</div>

<div style="flex:1;position:relative;overflow:hidden">

<div id="canvas-container"></div>

<div id="header">
  <h1>C2A2 &mdash; 3D PRS Landscape</h1>
  <div class="controls">
    <button onclick="resetCamera()">Reset View</button>
    <button id="btn-labels" onclick="toggleLabels()" class="active">Labels</button>
    <button id="btn-threads" onclick="toggleThreads()" class="active">Threads</button>
    <button id="btn-discs" onclick="toggleDiscs()" class="active">Disciplines</button>
  </div>
</div>

<div id="info-panel">
  <button class="close-btn" onclick="closePanel()">&times;</button>
  <div id="info-content"></div>
</div>

<div id="legend"></div>

<div id="tooltip"></div>

<div id="disc-labels"></div>

</div><!-- end flex:1 wrapper -->
</div><!-- end prs-layout -->

<script src="https://cdnjs.cloudflare.com/ajax/libs/three.js/r128/three.min.js"></script>
<script>
// ── DATA ──
var DISCIPLINES = """ + disc_data + """;
var THINKER_DISC = """ + thinker_disc_data + """;
var THINKER_COLORS = """ + thinker_color_data + """;
var THINKER_DISPLAY = """ + thinker_display_data + """;
var PRS_TRIPLETS = """ + triplet_data + """;
var CROSS_CONNECTIONS = """ + cross_data + """;
var FINDINGS = """ + finding_data + """;

// ── Z-AXIS: temporal placement (must be before camera state) ──
// Use pub_year for vertical placement; range spans ~1977-2026
var allYears = PRS_TRIPLETS.map(function(t) { return t.pub_year || 2020; });
var minYear = Math.min.apply(null, allYears);
var maxYear = Math.max.apply(null, allYears);
var zHeight = 40; // total vertical span

function yearToZ(year) {
  if (maxYear === minYear) return zHeight / 2;
  return 2 + ((year - minYear) / (maxYear - minYear)) * (zHeight - 4);
}

function dateToZ(dateStr) {
  if (!dateStr) return zHeight / 2;
  var year = parseInt(dateStr.slice(0, 4));
  return yearToZ(year);
}

// ── STATE ──
var scene, camera, renderer, raycaster, mouse;
var meshes = [];        // all clickable meshes
var threadLines = [];   // P-R-S connection lines
var discMeshes = [];    // discipline slice meshes
var labelSprites = [];  // text labels
var showLabels = true;
var showThreads = true;
var showDiscs = true;
var selectedMesh = null;
var hoveredMesh = null;

// Camera orbit
var isMouseDown = false;
var mouseDownPos = { x: 0, y: 0 };
var cameraTheta = Math.PI * 0.25;
var cameraPhi = Math.PI * 0.35;
var cameraRadius = 50;
var cameraTarget = new THREE.Vector3(0, zHeight / 2, 0);
var lastMouse = { x: 0, y: 0 };

// ── DISCIPLINE GEOMETRY ──
var discCount = DISCIPLINES.length;
var discAngle = (Math.PI * 2) / discCount;
var discRadius = 25;

function getDiscIndex(discipline) {
  return DISCIPLINES.indexOf(discipline);
}

function getDiscAngle(idx) {
  return idx * discAngle - Math.PI / 2;
}

// ── THINKER POSITION WITHIN DISCIPLINE ──
// Multiple thinkers may share a discipline; offset them within the slice
var thinkersByDisc = {};
Object.keys(THINKER_DISC).forEach(function(t) {
  var d = THINKER_DISC[t];
  if (!thinkersByDisc[d]) thinkersByDisc[d] = [];
  thinkersByDisc[d].push(t);
});

function getThinkerAngleOffset(thinker) {
  var disc = THINKER_DISC[thinker];
  var group = thinkersByDisc[disc] || [thinker];
  var idx = group.indexOf(thinker);
  var count = group.length;
  if (count <= 1) return 0;
  // Spread within the slice
  return (idx - (count - 1) / 2) * (discAngle * 0.5 / count);
}

// ── COUNT RESOURCE CONNECTIONS (pluripotency) ──
var resourceConnections = {};
PRS_TRIPLETS.forEach(function(t) {
  var rKey = t.resource.toLowerCase().trim().slice(0, 60);
  if (!resourceConnections[rKey]) resourceConnections[rKey] = [];
  resourceConnections[rKey].push(t.id);
});

function getResourceScale(triplet) {
  var rKey = triplet.resource.toLowerCase().trim().slice(0, 60);
  var count = (resourceConnections[rKey] || []).length;
  return 1 + Math.min(count - 1, 4) * 0.4;
}

// ── THREE.JS SETUP ──
function init() {
  scene = new THREE.Scene();
  scene.background = new THREE.Color(0x0a0a0f);
  scene.fog = new THREE.FogExp2(0x0a0a0f, 0.008);

  var container = document.getElementById('canvas-container');
  var cw = container.clientWidth;
  var ch = container.clientHeight;
  camera = new THREE.PerspectiveCamera(50, cw / ch, 0.1, 500);
  updateCameraPosition();

  // Try multiple renderer strategies
  var rendererCreated = false;
  var lastErr = '';
  var attempts = [
    { antialias: true, alpha: true },
    { antialias: false, alpha: false, failIfMajorPerformanceCaveat: false },
    { antialias: false, alpha: false, failIfMajorPerformanceCaveat: false, powerPreference: 'low-power' }
  ];
  for (var ai = 0; ai < attempts.length; ai++) {
    try {
      renderer = new THREE.WebGLRenderer(attempts[ai]);
      rendererCreated = true;
      break;
    } catch(e) {
      lastErr = e.message || String(e);
    }
  }
  if (!rendererCreated) {
    container.innerHTML = '<div style="display:flex;align-items:center;justify-content:center;height:100%;color:#C45B5B;font-size:16px;text-align:center;padding:40px;"><div><h2 style="color:#FFD700;margin-bottom:12px;">WebGL Unavailable</h2><p>Chrome refused to create a 3D context.</p><p style="margin-top:12px;"><button onclick="location.reload()" style="background:#FFD700;color:#0a0a0f;border:none;padding:8px 20px;border-radius:6px;cursor:pointer;font-size:14px;font-weight:600;">Retry</button></p></div></div>';
    return;
  }
  renderer.setPixelRatio(window.devicePixelRatio);
  renderer.setSize(cw, ch);
  container.appendChild(renderer.domElement);

  raycaster = new THREE.Raycaster();
  raycaster.params.Points = { threshold: 0.5 };
  mouse = new THREE.Vector2();

  // Lights
  var ambient = new THREE.AmbientLight(0x404060, 0.6);
  scene.add(ambient);
  var dirLight = new THREE.DirectionalLight(0xffffff, 0.8);
  dirLight.position.set(20, 40, 30);
  scene.add(dirLight);
  var pointLight = new THREE.PointLight(0xC9A84C, 0.4, 100);
  pointLight.position.set(0, zHeight, 0);
  scene.add(pointLight);

  buildDisciplineSlices();
  buildPRSNodes();
  buildThreads();
  buildLegend();
  buildCrossConnectionLines();

  // Events
  renderer.domElement.addEventListener('mousedown', onMouseDown);
  renderer.domElement.addEventListener('mousemove', onMouseMove);
  renderer.domElement.addEventListener('mouseup', onMouseUp);
  renderer.domElement.addEventListener('wheel', onWheel);
  renderer.domElement.addEventListener('dblclick', onDoubleClick);
  window.addEventListener('resize', onResize);

  animate();
}

// ── DISCIPLINE SLICES (floor pie) ──
function buildDisciplineSlices() {
  DISCIPLINES.forEach(function(disc, i) {
    var startAngle = getDiscAngle(i) - discAngle / 2;
    var endAngle = getDiscAngle(i) + discAngle / 2;

    // Create a filled wedge on the floor
    var shape = new THREE.Shape();
    shape.moveTo(0, 0);
    var segments = 24;
    for (var s = 0; s <= segments; s++) {
      var a = startAngle + (endAngle - startAngle) * (s / segments);
      shape.lineTo(Math.cos(a) * discRadius, Math.sin(a) * discRadius);
    }
    shape.lineTo(0, 0);

    var geo = new THREE.ShapeGeometry(shape);
    var mat = new THREE.MeshBasicMaterial({
      color: new THREE.Color(0x1a1a2e),
      transparent: true,
      opacity: 0.35,
      side: THREE.DoubleSide,
    });
    var mesh = new THREE.Mesh(geo, mat);
    mesh.rotation.x = -Math.PI / 2;
    mesh.position.y = 0;
    mesh.userData = { type: 'discipline', discipline: disc, index: i };
    scene.add(mesh);
    discMeshes.push(mesh);

    // Divider lines between slices
    var lineGeo = new THREE.BufferGeometry().setFromPoints([
      new THREE.Vector3(0, 0.05, 0),
      new THREE.Vector3(Math.cos(startAngle) * discRadius, 0.05, -Math.sin(startAngle) * discRadius),
    ]);
    var lineMat = new THREE.LineBasicMaterial({ color: 0x2a2a3e, transparent: true, opacity: 0.6 });
    var line = new THREE.Line(lineGeo, lineMat);
    scene.add(line);
    discMeshes.push(line);
  });
}

// ── PRS NODES ──
function buildPRSNodes() {
  PRS_TRIPLETS.forEach(function(triplet) {
    var disc = THINKER_DISC[triplet.thinker] || 'Systems Integration';
    var dIdx = getDiscIndex(disc);
    if (dIdx < 0) dIdx = 0;
    var baseAngle = getDiscAngle(dIdx);
    var thinkerOffset = getThinkerAngleOffset(triplet.thinker);
    var angle = baseAngle + thinkerOffset;

    var z = dateToZ(triplet.date);
    var color = new THREE.Color(THINKER_COLORS[triplet.thinker] || '#888888');

    // Place P, R, S as three connected nodes
    var prsTypes = ['problem', 'resource', 'solution'];
    var prsTexts = [triplet.problem, triplet.resource, triplet.solution];
    var radii = [0.35, 0.45 * getResourceScale(triplet), 0.35];
    var rOffsets = [0.6, 0.75, 0.9]; // radial position fraction within the slice

    var nodeGroup = [];

    prsTypes.forEach(function(pType, pi) {
      var r = discRadius * rOffsets[pi];
      var x = Math.cos(angle) * r;
      var yPos = z + pi * 1.2; // stack slightly along z (vertical)
      var zPos = -Math.sin(angle) * r;

      var nodeColor = color.clone();
      if (pType === 'problem') nodeColor.offsetHSL(0, 0, -0.1);
      if (pType === 'solution') nodeColor.offsetHSL(0, 0, 0.1);

      var geo;
      if (pType === 'problem') {
        // Octahedron for problems
        geo = new THREE.OctahedronGeometry(radii[pi], 0);
      } else if (pType === 'resource') {
        // Sphere for resources (scaled by pluripotency)
        geo = new THREE.SphereGeometry(radii[pi], 12, 8);
      } else {
        // Dodecahedron for solutions
        geo = new THREE.DodecahedronGeometry(radii[pi], 0);
      }

      var mat = new THREE.MeshPhongMaterial({
        color: nodeColor,
        emissive: nodeColor.clone().multiplyScalar(0.2),
        shininess: 40,
        transparent: true,
        opacity: 0.9,
      });
      var mesh = new THREE.Mesh(geo, mat);
      mesh.position.set(x, yPos, zPos);
      mesh.userData = {
        type: 'prs',
        prsType: pType,
        triplet: triplet,
        text: prsTexts[pi],
        thinker: triplet.thinker,
      };
      scene.add(mesh);
      meshes.push(mesh);
      nodeGroup.push(mesh);
    });

    // Connect P → R → S with thin lines
    if (nodeGroup.length === 3) {
      for (var li = 0; li < 2; li++) {
        var pts = [nodeGroup[li].position.clone(), nodeGroup[li + 1].position.clone()];
        var lGeo = new THREE.BufferGeometry().setFromPoints(pts);
        var lMat = new THREE.LineBasicMaterial({
          color: color,
          transparent: true,
          opacity: 0.5,
        });
        var line = new THREE.Line(lGeo, lMat);
        line.userData = { type: 'thread', thinker: triplet.thinker };
        scene.add(line);
        threadLines.push(line);
      }
    }
  });
}

// ── CROSS-TRADITION CONNECTION LINES ──
function buildCrossConnectionLines() {
  // Find triplets that share cross-connections via findings
  // Group triplets by thinker for cross-discipline arcs
  var thinkerTriplets = {};
  PRS_TRIPLETS.forEach(function(t) {
    if (!thinkerTriplets[t.thinker]) thinkerTriplets[t.thinker] = [];
    thinkerTriplets[t.thinker].push(t);
  });

  // Draw arcs between thinkers mentioned in the same finding
  FINDINGS.forEach(function(finding) {
    var progs = finding.programs.split(',').map(function(p) {
      return p.trim().replace(/ Agent$/, '').replace(/ \(.*$/, '').toLowerCase();
    });
    // Normalize to our thinker keys
    var thinkers = progs.filter(function(p) { return THINKER_COLORS[p]; });
    // Unique pairs
    for (var i = 0; i < thinkers.length; i++) {
      for (var j = i + 1; j < thinkers.length; j++) {
        var t1 = thinkerTriplets[thinkers[i]];
        var t2 = thinkerTriplets[thinkers[j]];
        if (!t1 || !t2 || !t1.length || !t2.length) continue;

        // Connect the resource nodes of the first triplet of each
        var r1Idx = meshes.findIndex(function(m) {
          return m.userData.type === 'prs' && m.userData.prsType === 'resource' && m.userData.thinker === thinkers[i];
        });
        var r2Idx = meshes.findIndex(function(m) {
          return m.userData.type === 'prs' && m.userData.prsType === 'resource' && m.userData.thinker === thinkers[j];
        });

        if (r1Idx >= 0 && r2Idx >= 0) {
          var p1 = meshes[r1Idx].position.clone();
          var p2 = meshes[r2Idx].position.clone();
          // Create curved arc
          var mid = p1.clone().add(p2).multiplyScalar(0.5);
          mid.y += 3; // arc upward
          var curve = new THREE.QuadraticBezierCurve3(p1, mid, p2);
          var points = curve.getPoints(20);
          var arcGeo = new THREE.BufferGeometry().setFromPoints(points);
          var arcMat = new THREE.LineBasicMaterial({
            color: 0xC9A84C,
            transparent: true,
            opacity: 0.15,
          });
          var arc = new THREE.Line(arcGeo, arcMat);
          arc.userData = { type: 'cross', finding: finding };
          scene.add(arc);
          threadLines.push(arc);
        }
      }
    }
  });
}

// ── THREADS VISIBILITY ──
function buildThreads() {
  // Already built in buildPRSNodes and buildCrossConnectionLines
}

// ── TRADITION FILTERS (left panel checkboxes) ──
var prsFilterState = {}; // thinker -> boolean

function buildTraditionFilters() {
  var container = document.getElementById('prs-tradition-filters');
  var html = '';
  var sortedThinkers = Object.keys(THINKER_DISPLAY).sort(function(a, b) {
    return THINKER_DISPLAY[a].localeCompare(THINKER_DISPLAY[b]);
  });
  sortedThinkers.forEach(function(t) {
    prsFilterState[t] = true;
    html += '<div class="prs-filter-item">';
    html += '<input type="checkbox" id="prs-chk-' + t + '" checked onchange="prsToggleThinker(\\'' + t + '\\', this.checked)">';
    html += '<span class="prs-filter-dot" style="background:' + THINKER_COLORS[t] + '"></span>';
    html += '<span class="prs-filter-label">' + THINKER_DISPLAY[t] + '</span>';
    html += '</div>';
  });
  container.innerHTML = html;
}

function prsToggleThinker(thinker, checked) {
  prsFilterState[thinker] = checked;
  applyPRSFilters();
  // Update All checkbox
  var allChecked = Object.keys(prsFilterState).every(function(t) { return prsFilterState[t]; });
  document.getElementById('prs-chk-all').checked = allChecked;
}

function prsToggleAll(checked) {
  Object.keys(prsFilterState).forEach(function(t) {
    prsFilterState[t] = checked;
    var chk = document.getElementById('prs-chk-' + t);
    if (chk) chk.checked = checked;
  });
  applyPRSFilters();
}

function applyPRSFilters() {
  meshes.forEach(function(m) {
    if (m.userData.thinker) {
      m.visible = prsFilterState[m.userData.thinker] !== false;
    }
  });
  threadLines.forEach(function(l) {
    if (l.userData.thinker) {
      l.visible = prsFilterState[l.userData.thinker] !== false && showThreads;
    } else if (l.userData.type === 'cross') {
      // Cross-connection arcs: visible if both connected thinkers are visible
      l.visible = showThreads;
    }
  });
}

// ── LEGEND (node shapes only now, thinker list moved to left panel) ──
function buildLegend() {
  var legendEl = document.getElementById('legend');
  var html = '<h4>Node Shapes</h4>';
  html += '<div class="legend-item"><span style="color:#E87070;font-size:14px">&#9670;</span> Problem</div>';
  html += '<div class="legend-item"><span style="color:#7AB0CF;font-size:14px">&#9679;</span> Resource</div>';
  html += '<div class="legend-item"><span style="color:#5DC0AB;font-size:14px">&#11206;</span> Solution</div>';
  legendEl.innerHTML = html;
}

// ── SEARCH ──
var prsSearchTimer = null;
function prsSearch(query) {
  var resultsEl = document.getElementById('prs-search-results');
  var clearBtn = document.getElementById('prs-search-clear');
  if (!query || query.length < 2) {
    resultsEl.innerHTML = '';
    clearBtn.style.display = 'none';
    // Reset all node opacity
    meshes.forEach(function(m) {
      if (m.userData.type === 'prs' && m.material) {
        m.material.opacity = 0.9;
        m.material.emissive.copy(new THREE.Color(THINKER_COLORS[m.userData.thinker] || '#888').multiplyScalar(0.2));
      }
    });
    return;
  }
  clearBtn.style.display = 'inline-block';

  // Check for API key — if available and query is 4+ chars, do semantic search
  var apiKey = '';
  try { apiKey = localStorage.getItem('tts_api_key') || ''; } catch(e) {}
  if (apiKey && query.length >= 4) {
    // Debounce semantic search
    if (prsSearchTimer) clearTimeout(prsSearchTimer);
    prsSearchTimer = setTimeout(function() { prsSemanticSearch(query, apiKey); }, 600);
    return;
  }

  // Fallback: text matching
  prsTextSearch(query);
}

function prsTextSearch(query) {
  var q = query.toLowerCase();
  var hits = [];
  PRS_TRIPLETS.forEach(function(t) {
    var searchable = (t.label + ' ' + t.problem + ' ' + t.resource + ' ' + t.solution).toLowerCase();
    if (searchable.indexOf(q) >= 0) {
      hits.push(t);
    }
  });
  // Also search cross-connections and findings
  CROSS_CONNECTIONS.forEach(function(c) {
    var searchable = (c.question + ' ' + c.programs + ' ' + c.nature + ' ' + (c.notes || '')).toLowerCase();
    if (searchable.indexOf(q) >= 0) {
      // Find related PRS triplets via program names
      var progs = c.programs.toLowerCase();
      PRS_TRIPLETS.forEach(function(t) {
        if (progs.indexOf(t.thinker) >= 0 && hits.indexOf(t) < 0) hits.push(t);
      });
    }
  });
  prsShowSearchResults(hits, query);
}

function prsSemanticSearch(query, apiKey) {
  var resultsEl = document.getElementById('prs-search-results');
  resultsEl.innerHTML = '<div style="color:#888;font-style:italic">Searching...</div>';

  // Build compact PRS summary for the LLM
  var prsText = PRS_TRIPLETS.map(function(t) {
    return t.id + ': ' + t.label + ' | P: ' + t.problem.slice(0, 120) + ' | R: ' + t.resource.slice(0, 120) + ' | S: ' + t.solution.slice(0, 120);
  }).join('\\n');

  var xhr = new XMLHttpRequest();
  xhr.open('POST', 'https://api.openai.com/v1/chat/completions', true);
  xhr.setRequestHeader('Authorization', 'Bearer ' + apiKey);
  xhr.setRequestHeader('Content-Type', 'application/json');
  xhr.timeout = 15000;
  xhr.onload = function() {
    if (xhr.status === 200) {
      try {
        var resp = JSON.parse(xhr.responseText);
        var content = resp.choices[0].message.content;
        // Parse out PRS IDs from the response
        var matchedIds = content.match(/[a-z]+-PRS-\\d+/gi) || [];
        var hits = [];
        matchedIds.forEach(function(id) {
          var t = PRS_TRIPLETS.find(function(p) { return p.id.toLowerCase() === id.toLowerCase(); });
          if (t && hits.indexOf(t) < 0) hits.push(t);
        });
        if (hits.length === 0) {
          // Fallback to text search
          prsTextSearch(query);
        } else {
          prsShowSearchResults(hits, query);
        }
      } catch(e) {
        prsTextSearch(query);
      }
    } else {
      prsTextSearch(query);
    }
  };
  xhr.onerror = function() { prsTextSearch(query); };
  xhr.ontimeout = function() { prsTextSearch(query); };
  xhr.send(JSON.stringify({
    model: 'gpt-4o-mini',
    messages: [
      { role: 'system', content: 'You are a search assistant. Given PRS triplets (Problem-Resource-Solution) from research traditions, return the IDs of triplets most relevant to the user query. Return ONLY a comma-separated list of IDs (e.g. levin-PRS-01, friston-PRS-03). No explanation.' },
      { role: 'user', content: 'Query: ' + query + '\\n\\nPRS Triplets:\\n' + prsText }
    ],
    max_tokens: 200,
    temperature: 0.1
  }));
}

function prsShowSearchResults(hits, query) {
  var resultsEl = document.getElementById('prs-search-results');

  // Dim non-matching nodes, highlight matching
  var hitIds = {};
  hits.forEach(function(h) { hitIds[h.id] = true; });
  meshes.forEach(function(m) {
    if (m.userData.type === 'prs') {
      var isHit = hitIds[m.userData.triplet.id];
      m.material.opacity = isHit ? 1.0 : 0.15;
      if (isHit) {
        m.material.emissive.setHex(0x555555);
      } else {
        m.material.emissive.copy(new THREE.Color(THINKER_COLORS[m.userData.thinker] || '#888').multiplyScalar(0.1));
      }
    }
  });

  var html = '<div style="color:#888;margin-bottom:4px">' + hits.length + ' result' + (hits.length !== 1 ? 's' : '') + '</div>';
  hits.slice(0, 15).forEach(function(h) {
    var tName = THINKER_DISPLAY[h.thinker] || h.thinker;
    var tColor = THINKER_COLORS[h.thinker] || '#888';
    html += '<div class="prs-search-hit" onclick="prsSearchClickResult(\\'' + h.id + '\\')">';
    html += '<span class="hit-thinker" style="color:' + tColor + '">' + tName + '</span> ';
    html += '<span>' + h.label + '</span>';
    html += '</div>';
  });
  if (hits.length > 15) {
    html += '<div style="color:#666;font-size:10px;margin-top:4px">...and ' + (hits.length - 15) + ' more</div>';
  }
  resultsEl.innerHTML = html;
}

function prsSearchClickResult(tripletId) {
  // Find the resource node for this triplet and click it
  var target = meshes.find(function(m) {
    return m.userData.type === 'prs' && m.userData.prsType === 'resource' && m.userData.triplet && m.userData.triplet.id === tripletId;
  });
  if (target) {
    showNodeInfo(target);
    // Center camera on it
    cameraTarget.copy(target.position);
    cameraRadius = 30;
    updateCameraPosition();
  }
}

function prsClearSearch() {
  document.getElementById('prs-search-box').value = '';
  prsSearch('');
}

// ── CAMERA ──
function updateCameraPosition() {
  var x = cameraRadius * Math.sin(cameraPhi) * Math.cos(cameraTheta);
  var y = cameraRadius * Math.cos(cameraPhi);
  var z = cameraRadius * Math.sin(cameraPhi) * Math.sin(cameraTheta);
  camera.position.set(
    cameraTarget.x + x,
    cameraTarget.y + y,
    cameraTarget.z + z
  );
  camera.lookAt(cameraTarget);
}

function resetCamera() {
  cameraTheta = Math.PI * 0.25;
  cameraPhi = Math.PI * 0.35;
  cameraRadius = 50;
  cameraTarget.set(0, zHeight / 2, 0);
  updateCameraPosition();
}

// ── EVENTS ──
function onMouseDown(e) {
  isMouseDown = true;
  mouseDownPos = { x: e.clientX, y: e.clientY };
  lastMouse = { x: e.clientX, y: e.clientY };
}

function onMouseMove(e) {
  if (isMouseDown) {
    var dx = e.clientX - lastMouse.x;
    var dy = e.clientY - lastMouse.y;
    cameraTheta -= dx * 0.005;
    cameraPhi = Math.max(0.1, Math.min(Math.PI * 0.85, cameraPhi - dy * 0.005));
    updateCameraPosition();
    lastMouse = { x: e.clientX, y: e.clientY };
  }

  // Hover detection
  var rect = renderer.domElement.getBoundingClientRect();
  mouse.x = ((e.clientX - rect.left) / rect.width) * 2 - 1;
  mouse.y = -((e.clientY - rect.top) / rect.height) * 2 + 1;
  raycaster.setFromCamera(mouse, camera);

  var intersects = raycaster.intersectObjects(meshes);
  var tooltip = document.getElementById('tooltip');
  renderer.domElement.style.cursor = 'default';

  if (intersects.length > 0) {
    var hit = intersects[0].object;
    if (hit.userData.type === 'prs') {
      renderer.domElement.style.cursor = 'pointer';
      hoveredMesh = hit;

      var typeLabel = hit.userData.prsType.charAt(0).toUpperCase() + hit.userData.prsType.slice(1);
      var tName = THINKER_DISPLAY[hit.userData.thinker] || hit.userData.thinker;
      tooltip.innerHTML = '<strong>' + tName + '</strong> &mdash; ' + typeLabel +
        '<br><span style="color:#888">' + (hit.userData.text || '').slice(0, 120) + '</span>';
      tooltip.style.display = 'block';
      tooltip.style.left = (e.clientX + 14) + 'px';
      tooltip.style.top = (e.clientY + 14) + 'px';

      // Highlight
      if (selectedMesh !== hit) {
        hit.material.emissive.setHex(0x444444);
      }
    }
  } else {
    if (hoveredMesh && hoveredMesh !== selectedMesh) {
      var origColor = new THREE.Color(THINKER_COLORS[hoveredMesh.userData.thinker] || '#888888');
      hoveredMesh.material.emissive.copy(origColor.multiplyScalar(0.2));
    }
    hoveredMesh = null;
    tooltip.style.display = 'none';
  }
}

function onMouseUp(e) {
  isMouseDown = false;
  var dist = Math.sqrt(Math.pow(e.clientX - mouseDownPos.x, 2) + Math.pow(e.clientY - mouseDownPos.y, 2));
  if (dist < 5) {
    // It's a click, not a drag
    onClick(e);
  }
}

function onClick(e) {
  var rect = renderer.domElement.getBoundingClientRect();
  mouse.x = ((e.clientX - rect.left) / rect.width) * 2 - 1;
  mouse.y = -((e.clientY - rect.top) / rect.height) * 2 + 1;
  raycaster.setFromCamera(mouse, camera);

  var intersects = raycaster.intersectObjects(meshes);

  if (intersects.length > 0) {
    var hit = intersects[0].object;
    if (hit.userData.type === 'prs') {
      showNodeInfo(hit);
    }
  } else {
    closePanel();
  }
}

function onDoubleClick(e) {
  // Double-click to center on a node
  var rect = renderer.domElement.getBoundingClientRect();
  mouse.x = ((e.clientX - rect.left) / rect.width) * 2 - 1;
  mouse.y = -((e.clientY - rect.top) / rect.height) * 2 + 1;
  raycaster.setFromCamera(mouse, camera);
  var intersects = raycaster.intersectObjects(meshes);
  if (intersects.length > 0) {
    cameraTarget.copy(intersects[0].object.position);
    updateCameraPosition();
  }
}

function onWheel(e) {
  cameraRadius = Math.max(15, Math.min(120, cameraRadius + e.deltaY * 0.05));
  updateCameraPosition();
  e.preventDefault();
}

function onResize() {
  var container = document.getElementById('canvas-container');
  var w = container.clientWidth;
  var h = container.clientHeight;
  camera.aspect = w / h;
  camera.updateProjectionMatrix();
  renderer.setSize(w, h);
}

// ── INFO PANEL ──
function showNodeInfo(mesh) {
  selectedMesh = mesh;
  var d = mesh.userData;
  var triplet = d.triplet;
  var panel = document.getElementById('info-panel');
  var content = document.getElementById('info-content');

  var typeClass = d.prsType;
  var typeLabel = d.prsType.charAt(0).toUpperCase() + d.prsType.slice(1);
  var tName = THINKER_DISPLAY[d.thinker] || d.thinker;
  var tColor = THINKER_COLORS[d.thinker] || '#888';
  var disc = THINKER_DISC[d.thinker] || '';

  var html = '<h3>' + triplet.label + '</h3>';
  html += '<span class="thinker-tag" style="background:' + tColor + '33;color:' + tColor + '">' + tName + '</span>';
  html += '<span class="prs-type ' + typeClass + '">' + typeLabel + '</span>';
  html += '<div class="field-label">Discipline</div>';
  html += '<div class="field-value">' + disc + '</div>';
  html += '<div class="field-label">Problem</div>';
  html += '<div class="field-value">' + triplet.problem + '</div>';
  html += '<div class="field-label">Resource</div>';
  html += '<div class="field-value">' + triplet.resource + '</div>';
  html += '<div class="field-label">Solution</div>';
  html += '<div class="field-value">' + triplet.solution + '</div>';
  html += '<div class="field-label">Publication Year</div>';
  html += '<div class="field-value">' + (triplet.pub_year || 'Unknown') + '</div>';
  html += '<div class="field-label">Confidence</div>';
  html += '<div class="field-value">' + triplet.confidence + '</div>';

  // Find related cross-connections
  var related = CROSS_CONNECTIONS.filter(function(cc) {
    var progs = cc.programs.toLowerCase();
    return progs.indexOf(d.thinker) >= 0 || progs.indexOf(tName.toLowerCase()) >= 0;
  });
  if (related.length > 0) {
    html += '<div class="field-label" style="margin-top:14px">Cross-Tradition Connections</div>';
    related.forEach(function(cc) {
      html += '<div class="field-value" style="margin-top:6px;padding:6px;background:#1a1a2e;border-radius:4px">';
      html += '<strong>' + cc.id + ':</strong> ' + cc.question;
      html += '<br><span style="color:#888;font-size:11px">' + cc.nature + '</span>';
      html += '</div>';
    });
  }

  content.innerHTML = html;
  panel.style.display = 'block';
}

function closePanel() {
  document.getElementById('info-panel').style.display = 'none';
  if (selectedMesh) {
    var origColor = new THREE.Color(THINKER_COLORS[selectedMesh.userData.thinker] || '#888888');
    selectedMesh.material.emissive.copy(origColor.multiplyScalar(0.2));
  }
  selectedMesh = null;
}

// ── TOGGLE CONTROLS ──
function toggleLabels() {
  showLabels = !showLabels;
  document.getElementById('btn-labels').classList.toggle('active', showLabels);
  document.getElementById('disc-labels').style.display = showLabels ? 'block' : 'none';
}

function toggleThreads() {
  showThreads = !showThreads;
  document.getElementById('btn-threads').classList.toggle('active', showThreads);
  threadLines.forEach(function(l) { l.visible = showThreads; });
}

function toggleDiscs() {
  showDiscs = !showDiscs;
  document.getElementById('btn-discs').classList.toggle('active', showDiscs);
  discMeshes.forEach(function(m) { m.visible = showDiscs; });
}

// ── DISCIPLINE LABELS (2D overlay) ──
function updateDiscLabels() {
  if (!showLabels) return;
  var container = document.getElementById('disc-labels');
  container.innerHTML = '';
  var canvasRect = renderer.domElement.getBoundingClientRect();
  DISCIPLINES.forEach(function(disc, i) {
    var angle = getDiscAngle(i);
    var r = discRadius + 3;
    var worldPos = new THREE.Vector3(
      Math.cos(angle) * r,
      0.5,
      -Math.sin(angle) * r
    );
    var screenPos = worldPos.project(camera);
    var x = (screenPos.x * 0.5 + 0.5) * canvasRect.width;
    var y = (-screenPos.y * 0.5 + 0.5) * canvasRect.height;

    if (screenPos.z < 1) {
      var label = document.createElement('div');
      label.className = 'disc-label';
      label.textContent = disc;
      label.style.left = x + 'px';
      label.style.top = y + 'px';
      label.style.transform = 'translate(-50%, -50%)';
      container.appendChild(label);
    }
  });
}

// ── Z-AXIS MARKERS ──
function buildZAxis() {
  // Vertical line at center
  var topY = zHeight + 2;
  var pts = [new THREE.Vector3(0, 0, 0), new THREE.Vector3(0, topY, 0)];
  var axGeo = new THREE.BufferGeometry().setFromPoints(pts);
  var axMat = new THREE.LineBasicMaterial({ color: 0x2a2a3e, transparent: true, opacity: 0.4 });
  scene.add(new THREE.Line(axGeo, axMat));

  // Decade markers along the axis
  var startDecade = Math.ceil(minYear / 10) * 10;
  for (var yr = startDecade; yr <= maxYear; yr += 10) {
    var y = yearToZ(yr);
    // Horizontal tick
    var tickPts = [new THREE.Vector3(-1, y, 0), new THREE.Vector3(1, y, 0)];
    var tickGeo = new THREE.BufferGeometry().setFromPoints(tickPts);
    var tickMat = new THREE.LineBasicMaterial({ color: 0x3a3a4e, transparent: true, opacity: 0.5 });
    scene.add(new THREE.Line(tickGeo, tickMat));

    // Faint horizontal ring at each decade
    var ringGeo = new THREE.RingGeometry(discRadius - 0.5, discRadius + 0.5, 64);
    var ringMat = new THREE.MeshBasicMaterial({ color: 0x1a1a2e, transparent: true, opacity: 0.12, side: THREE.DoubleSide });
    var ring = new THREE.Mesh(ringGeo, ringMat);
    ring.rotation.x = -Math.PI / 2;
    ring.position.y = y;
    scene.add(ring);
  }
}

// Year labels rendered as 2D overlays
function updateYearLabels() {
  var container = document.getElementById('disc-labels');
  var canvasRect = renderer.domElement.getBoundingClientRect();
  var startDecade = Math.ceil(minYear / 10) * 10;
  for (var yr = startDecade; yr <= maxYear; yr += 10) {
    var y = yearToZ(yr);
    var worldPos = new THREE.Vector3(2, y, 0);
    var screenPos = worldPos.project(camera);
    var sx = (screenPos.x * 0.5 + 0.5) * canvasRect.width;
    var sy = (-screenPos.y * 0.5 + 0.5) * canvasRect.height;
    if (screenPos.z < 1) {
      var label = document.createElement('div');
      label.className = 'disc-label';
      label.textContent = yr.toString();
      label.style.left = sx + 'px';
      label.style.top = sy + 'px';
      label.style.transform = 'translate(-50%, -50%)';
      label.style.color = '#C9A84C';
      label.style.fontSize = '13px';
      label.style.fontWeight = '600';
      container.appendChild(label);
    }
  }
}

// ── ANIMATE ──
function animate() {
  requestAnimationFrame(animate);

  // Slow rotation of nodes for visual interest
  meshes.forEach(function(m) {
    if (m.userData.type === 'prs') {
      m.rotation.y += 0.003;
      if (m.userData.prsType === 'problem') m.rotation.x += 0.002;
    }
  });

  renderer.render(scene, camera);
  updateDiscLabels();
  updateYearLabels();
}

// ── SEARCH EVENT ──
document.getElementById('prs-search-box').addEventListener('input', function(e) {
  prsSearch(e.target.value);
});

// ── INIT ──
init();
buildZAxis();
buildTraditionFilters();
</script>
</body>
</html>"""

    return html


def main():
    if len(sys.argv) < 3:
        print(f"Usage: {sys.argv[0]} <vault_data.json> <output.html>")
        sys.exit(1)

    vault_path = sys.argv[1]
    output_path = sys.argv[2]

    with open(vault_path) as f:
        data = json.load(f)

    triplets = parse_prs_triplets(data)
    crosses = parse_cross_connections(data)
    findings = parse_findings(data)

    print(f"Parsed {len(triplets)} PRS triplets from {len(set(t['thinker'] for t in triplets))} thinkers")
    print(f"Parsed {len(crosses)} cross-connections, {len(findings)} findings")

    html = build_html(triplets, crosses, findings, data)

    with open(output_path, "w") as f:
        f.write(html)

    print(f"Generated: {output_path}")
    print(f"Size: {len(html)} chars")


if __name__ == "__main__":
    main()
